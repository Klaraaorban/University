#include <iostream>
#include "Graph.h"
#include "Graph2.h"
using namespace std;
int main() {

//    Graph g;
//    cout<<g.isEdge(0,1)<<endl;
//    g.printGraph();
//    cout<<g.maximalGrad()<<endl;
//    cout<<g.minimalGrad()<<endl;

    Graph2 g;
    cout<<g.isEdge(0,1)<<endl;
    g.printGraph();
    return 0;
}
